# pay-with-life-chrome-extension
Chrome extension, called "pay with life", which shows how much time something costs you
